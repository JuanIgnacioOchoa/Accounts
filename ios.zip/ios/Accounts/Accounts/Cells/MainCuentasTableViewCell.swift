//
//  MainCuentasTableViewCell.swift
//  Accounts
//
//  Created by Juan Ochoa on 9/11/19.
//  Copyright © 2019 Juan Ochoa. All rights reserved.
//

import UIKit

class MainCuentasTableViewCell: UITableViewCell {
    
    @IBOutlet weak var cantidadLbl: UILabel!
    @IBOutlet weak var cuentasLbl: UILabel!
    
    func setCell(data: String){
        cantidadLbl.text = data
        cuentasLbl.text = data
    }
}
