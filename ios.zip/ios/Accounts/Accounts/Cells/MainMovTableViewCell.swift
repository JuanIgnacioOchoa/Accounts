//
//  MainMovTableViewCell.swift
//  Accounts
//
//  Created by Juan Ochoa on 9/12/19.
//  Copyright © 2019 Juan Ochoa. All rights reserved.
//

import UIKit

class MainMovTableViewCell: UITableViewCell {

    @IBOutlet weak var fechaLbl: UILabel!
    @IBOutlet weak var cuentaLbl: UILabel!
    @IBOutlet weak var cantidadLbl: UILabel!
    @IBOutlet weak var monedaLbl: UILabel!
    @IBOutlet weak var motivoLbl: UILabel!
    
    func setCell(){
        
    }
    
}
