//
//  DataViewController.swift
//  Accounts
//
//  Created by Juan Ochoa on 9/11/19.
//  Copyright © 2019 Juan Ochoa. All rights reserved.
//

import UIKit

class DataViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var display: UILabel!
    
    var displayString: String?
    var index: Int?
    var dataArray = ["9", "8", "7"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        display.text = displayString
    }
    
}

extension DataViewController: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(index == 0){
            tableView.rowHeight = 50
        } else {
            tableView.rowHeight = 100
        }
        return dataArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //let data = dataArray[indexPath.row]
        let cell: UITableViewCell
        if(index == 0){
            cell = tableView.dequeueReusableCell(withIdentifier: "MainCuentasCell") as! MainCuentasTableViewCell
        } else {
            cell = tableView.dequeueReusableCell(withIdentifier: "MainMovCell") as! MainMovTableViewCell
        }
        //cell.setCell(data: data)
        return cell
    }
}
