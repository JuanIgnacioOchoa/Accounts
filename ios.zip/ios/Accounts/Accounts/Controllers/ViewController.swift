//
//  ViewController.swift
//  Accounts
//
//  Created by Juan Ochoa on 9/11/19.
//  Copyright © 2019 Juan Ochoa. All rights reserved.
//

import UIKit
import GoogleSignIn

class ViewController: UIViewController {

    @IBAction func btnClick(_ sender: UIButton) {
        GIDSignIn.sharedInstance()?.signIn()
    }
    @IBOutlet weak var contentView: UIView!
    
    let dataSource = ["cuentas", "movimientos"]
    let currentViewControllerIndex = 0
    let dataArray1 = ["1", "2", "3"]
    let dataArray2 = ["a", "b", "c"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NSLog("Hola0")
        // Do any additional setup after loading the view.
        configurePageViewController()
        let database = Database()
    }

    func configurePageViewController(){
        NSLog("Hola01")
        guard let pageViewController = storyboard?.instantiateViewController(withIdentifier: "PageControllerOne")
            as? UIPageViewController else {
                NSLog("Hola1")
                return
        }
        pageViewController.delegate = self
        pageViewController.dataSource = self
        
        addChild(pageViewController)
        pageViewController.didMove(toParent: self)
        
        pageViewController.view.translatesAutoresizingMaskIntoConstraints = false
        
        contentView.addSubview(pageViewController.view)
        NSLog("Hola02")
        let views: [String: Any] = ["pageView": pageViewController.view as Any]
        
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[pageView]-0-|",
                                                                 options: NSLayoutConstraint.FormatOptions(rawValue: 0),
                                                                 metrics: nil,
                                                                 views: views))
        contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[pageView]-0-|",
                                                                 options: NSLayoutConstraint.FormatOptions(rawValue: 0),
                                                                 metrics: nil,
                                                                 views: views))
        
        guard let startingViewController = detailViewControllerAt(index: currentViewControllerIndex) else {
            NSLog("Hola2")
            return
        }
        NSLog("Hola03")
        pageViewController.setViewControllers([startingViewController], direction: .forward, animated: true)
        NSLog("Hola030")
    }

    func detailViewControllerAt(index: Int) -> DataViewController? {
        NSLog("Hola04")
        if index >= dataSource.count || dataSource.count == 0 {
            NSLog("Hola3")
            return nil
        }
        
        guard let dataViewController = storyboard?.instantiateViewController(withIdentifier: String(describing: DataViewController.self))
            as? DataViewController else {
            return nil
        }
        NSLog("Hola05")
        dataViewController.index = index
        dataViewController.displayString = dataSource[index]
        NSLog("Hola06")
        if(index == 0) {
            dataViewController.dataArray = dataArray1
        } else {
            dataViewController.dataArray = dataArray2
        }
        return dataViewController
    }
}

extension ViewController: UIPageViewControllerDelegate, UIPageViewControllerDataSource{
    func presentationIndex(for pageViewController: UIPageViewController) -> Int {
        return currentViewControllerIndex
    }
    
    func presentationCount(for pageViewController: UIPageViewController) -> Int {
        return dataSource.count
    }
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        let dataViewController = viewController as? DataViewController
        
        guard var currentIndex = dataViewController?.index else {
            return nil
        }
        if currentIndex == 0{
            return nil
        }
        
        currentIndex -= 1
        
        return detailViewControllerAt(index: currentIndex)
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        let dataViewController = viewController as? DataViewController
        
        guard var currentIndex = dataViewController?.index else {
            return nil
        }
        if currentIndex == dataSource.count{
            return nil
        }
        
        currentIndex += 1
        
        return detailViewControllerAt(index: currentIndex)
    }
}
